<template>
  <div>
    <h3>欢迎来到GINBLOG后台管理页面</h3>
  </div>
</template>
