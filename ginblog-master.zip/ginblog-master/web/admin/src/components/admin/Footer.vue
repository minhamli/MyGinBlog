<template>
  <div class="footer">
    <span>---- GinBlog Admin ----</span>
  </div>
</template>

<style scoped>
.footer {
  background-color: #eee;
  text-align: center;
  height: 100%;
}
.footer span {
  height: 100%;
  font-size: 18px;
}
</style>
